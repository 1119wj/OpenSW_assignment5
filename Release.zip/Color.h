#pragma once
#define BLACK 0
#define darkBLUE 1
#define darkGREEN 2
#define darkSKYBLUE 3
#define darkRED 4
#define darkPURPLE 5
#define darkYELLOW 6
#define GRAY 7
#define darkGRAY 8
#define BLUE 9
#define GREEN 10
#define SKYBLUE 11
#define RED 12
#define PURPLE 13
#define YELLOW 14
#define WHITE 15

void textcolor(int colorNum);
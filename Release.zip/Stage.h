﻿#pragma once
#define STAGETIME 200

void StartStage(int stageNum); //스테이지 세팅 및 시작
void NormalStage(); //일반 스테이지
void BossStage(); //보스 스테이지; 미작성
void PauseGame(); //게임 일시정지